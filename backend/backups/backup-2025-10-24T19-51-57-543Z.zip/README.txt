CSV Backup Files - Format Explanation

Each CSV file contains data from the corresponding MongoDB collection.

Special Formatting:
- MongoDB ObjectId fields are converted to string format
- Date fields are converted to ISO string format (YYYY-MM-DDTHH:mm:ss.sssZ)
- Nested objects are converted to JSON strings
- Arrays are converted to JSON strings
- Boolean values are converted to 'true'/'false' strings
- Buffer objects are converted to hex strings

Files included:
- users.csv: System users data
- inmates.csv: Inmate records
- visitors.csv: Visitor records  
- guests.csv: Guest records
- crimes.csv: Crime definitions
- visit_logs.csv: Visit history logs

Backup created: 2025-10-24T19:51:57.567Z
